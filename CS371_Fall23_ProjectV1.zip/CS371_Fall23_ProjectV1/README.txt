Contact Info
============

Group Members & Email Addresses:

    Tharanie Subramaniam, tsu241@uky.edu
    Joshna Sravanthi Kurra, jku230@uky.edu

Versioning
==========

Github Link: https://github.com/pryoxy/371PongProject.git

General Info
============
This file describes how to install/run your program and anything else you think the user should know

Install Instructions
====================

Run the following line to install the required libraries for this project:

`pip3 install -r requirements.txt`

Known Bugs
==========
- The server doesn't work because the logic isn't yet written.
- The client doesn't speak to the server

